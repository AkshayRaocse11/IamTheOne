﻿namespace SlidingTabLayoutTutorial
{
    internal class ViewPager
    {
    }
}